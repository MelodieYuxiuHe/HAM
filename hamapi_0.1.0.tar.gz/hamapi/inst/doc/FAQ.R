## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include = FALSE---------------------------------------------------
library(hamapi)

## -----------------------------------------------------------------------------
#> artresult <- get_artwork_info(classification='Prints', size=10)
#>
# NULL

