## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include=FALSE-----------------------------------------------------
library(hamapi)

## -----------------------------------------------------------------------------
#Please input your token. (WITHOUT THE ' ')
get_token()

#Congrats! Your token is now saved as a global variable and can be used in other functions in this package. 

