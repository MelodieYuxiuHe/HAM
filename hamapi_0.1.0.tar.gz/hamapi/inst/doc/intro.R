## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include = FALSE---------------------------------------------------
library(hamapi)

## -----------------------------------------------------------------------------
#Please input your token. (WITHOUT THE ' ')
#get_token()
token <- get_token()
assign("token", token, envir = globalenv())

#IMPORTANT: plese excute both lines when using this package. Otherwise the token is not specified as a global variable. Thank you!
#Congrats! Your token is now saved as a global variable and can be used in other functions in this package. 

## -----------------------------------------------------------------------------
#Check if your input of classification is valid. 

#The input of this function is class. You can specify `class = "Your chosen classification"`
is_classification(
  class="Prints")
#Whether the classification is a valid one for Harvard Art Museum API? 

is_classification(class="Prints")
#Run this chunk and you will get an output "TRUE". This shows that "Prints" is within the valid calssification of HAM.

is_classification(class="Music")
#Run this chunk and you will get an output "FALSE". This shows that "Datascience" is not within the valid calssification of HAM. 

## -----------------------------------------------------------------------------
#This function get artwork information by classification.

#There are 2 input variables: The classification and size

artresult <- get_artwork_info(

  classification='Prints', 
#This is the HAM available classification, if this is not a valid classification. 
#The function inside this function (is_classification) will let you know that this is not valid.
 
  size=10)
#This is the number of artworks that you want to get from this function. The limit here is set to be 100. 
#If you have an input of size > 100, it will stop and produce an error "API limit exceeded".

#In some cases, the API may fail to return valid information. If the status code is not 200, this function will stop and produce "Harvard Art Museum request failed"

artresult
#Now you may see the complete result from this function. With the input "Prints" and "size=10". You get a list which contains information about the 10 artworks under the category of "Print". 

#Different version of R Studio may display it differently. Please open it on the right top of R Stuio if it cannot be fully displayed. : )

#You will have information about the title, century, period, culture, division, classification, department, object id, the corresponding URL on the website and the corresponding image url of the artwork.

#For example, you can see for "Women and Male Attendant at the Shore (Enoshima?)", it is completed in 18th century in Edo period, 1615-1868. It is under Japanese culture. It belongs to the Asian and Mediterranean Art division. It belongs to Department of Asian Art. The url is also in the result "https://www.harvardartmuseums.org/collections/object/203554". Please feel free to browse the website if your are interested in. 


## -----------------------------------------------------------------------------
get_artwork_info(classification='Prints', size=20)

## -----------------------------------------------------------------------------
#library(utils)
#library(httr)
#get_picture <- function(classification = 'Prints', size=10, numberp=7){
#   if (numberp > size){
#     stop(
#       sprintf(
#         "You cannot download pictures more than your input size"
#       ),
#       call. = FALSE
#     )
#   }
#   if (numberp > 5){
#     continue <- dlg_message("Your mac/pc will be flooded by pictures. Do you want to continue?", "yesno")$res
#     if (continue == 'no'){
#       stop(
#         sprintf(
#           "Try a smaller number : )"
#         ),
#         call. = FALSE
#       )
#     }
#     if (continue == 'yes'){
#       resultform <- get_artwork_info(classification=classification, size=size)
#       objectid1 <- resultform[,8]
#       imageurls <- as.vector(unlist(resultform[, 10]))
#       nameimage <- list()
#       for (i in 1:numberp){
#         nameimage[i] <- paste(objectid1[[i]],'.jpeg',sep="")
#         download.file(url = as.character(imageurls[i]), destfile = as.character(nameimage[i]),
#         quiet = FALSE, mode="w",cacheOK=TRUE)
#         #curl_download(as.character(imageurls[i]), destfile = as.character(nameimage[i]),
#          #             quiet = FALSE, handle = new_handle())
#       }
#       print("Hooray! finished")
#     }
#   }
#   if (numberp <= 5){
#     resultform <- get_artwork_info(classification=classification, size=size)
#     objectid1 <- resultform[,8]
#     imageurls <- as.vector(unlist(resultform[, 10]))
#     for (i in 1:numberp){
#       nameimage <- list()
#       nameimage[i] <- paste(objectid1[[i]],'.jpeg',sep="")
#       download.file(imageurls[i], destfile = as.character(nameimage[i]),
#                     quiet = FALSE, mode="w",cacheOK=TRUE)
#     }
#     print("Hooray! finished")
#   }
# }

## -----------------------------------------------------------------------------
#get_picture(size=10, numberp = 2, classification = 'Vessels')
#get_picture(size=5, numberp = 2, classification = 'Prints')

## -----------------------------------------------------------------------------
#There are 2 input variables: The classification and size

galleryr <- get_gallery_info(
  
  #This is the floor of Harvard Art Museum.
  #The function will let you know if this is not a valid input. If the input is larger than 3, it will stop and give a message "Only Floor 1 - Floor 3 have galleries".
  
  floor=2,
  
  #This is the number of galleries that you want to get from this floor. Different floor has different number of galleries. The function will let you know if your input is not a valid combination. For example, if you input floor = 2 and size = 50, it will return "Second floor only have 24 galleries". The combinations are (Floor1 20, Floor2 24, Floor 12)
  size=10)

#In some cases, the API may fail to return valid information. If the status code is not 200, this function will stop and produce "Harvard Art Museum request failed"

#Now please have a look of the result. 
galleryr

#Now you may see the complete result from this function. With the input "floor = 2" and "size=10". You get a list which contains information about the 10 galleries on the second floor. 

#Different version of R Studio may display it differently. Please open it on the right top of R Stuio if it cannot be fully displayed. : )

#You will have information about the gallery name, theme, galleryid, floor, the number of object in the gallery(objectcount), gallery text description (labeltext), the corresponding URL on the website.

#For example, you can see for "European and American Art, 17th–19th century", the theme is "The Emergence of Romanticism in Early Nineteenth-Century France". It is on the second floor with 22 objects inside it. 

#The text description is "A sustained commitment to the tenets of neoclassicism persisted after the French Revolution, and artists such as Jacques-Louis David and his school continued to adhere to the sculptural and archaeological approach to form that they had helped popularize in the previous century. However, their style was soon challenged by romanticism, which proposed a radically different kind of representation. Its development over the first half of the nineteenth century produced myriad reformulations and contradictions in its definition. But at its height, romantic painting was characterized by a bold and vibrant palette and by loose and expressive brushstrokes that often obscured any careful preparatory drawing beneath the composition. Nature, as a powerful force and stimulant for extreme human emotions, was a favored focus, as were literary subjects and the poetry of William Shakespeare and Lord Byron. The artist was viewed as a unique conduit for those elements through his work. The years 1823–24 marked a watershed moment for romanticism in France, with the publication of the first part of Stendhal’s Racine and Shakespeare, which enumerated the limitations of the classicist tradition, and with the Salon of 1824, where critics compared history paintings by Jean-Auguste-Dominique Ingres and Eugène Delacroix, and there, too, found classicism wanting. Adopting the terminology of the German critic Friedrich von Schlegel, who had earlier pitted romanticism against classicism, critics heralded Ingres as a classicist and Delacroix as a romantic—figureheads of antithetical styles, even though many of the same concerns underpinned both artists’ approaches. Delacroix, in fact, claimed he was not a “romantic” at all."

#The url is also in the result "https://www.harvardartmuseums.org/visit/floor-plan/2/2200" Please feel free to browse the website if your are interested in. 


## -----------------------------------------------------------------------------
get_gallery_info(floor=2, size=14)
get_gallery_info(floor=1, size=12)

## -----------------------------------------------------------------------------
#Sometimes you are in a hurry, or you just curious about which gallery under your specied floor has the most artworks. 

#There are 2 input variables: The classification and size

#most_object(floor=2, size=24)

#Run this chunk, you will know that among the 24 galleries on the second floor. "The European and American Art, 17th–19th century" has the most artworks collections.

