## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include=FALSE-----------------------------------------------------
library(hamapi)

## -----------------------------------------------------------------------------
#library(devtools)
#install_github("MelodieYuxiuHe/HAM/hamapi")

